
import os

TELEGRAM_BOT_TOKEN = os.environ.get("BOT_TOKEN")
CLAIM_API_URL = "https://testnet.humanity.org/api/rewards/daily/claim"
BALANCE_API_URL = "https://testnet.humanity.org/api/rewards/balance"
